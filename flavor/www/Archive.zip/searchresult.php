<?php
    /* $GET_['q']; */
    echo "hello";
?>